package constants

const (
	RoleAdmin = "admin"
	RoleUser  = "user"
)
